const CONFIG = {
    API_URL: "https://slow-bars-shop.loca.lt",
    FRONTEND_URL: "https://social-crews-argue.loca.lt"
};
